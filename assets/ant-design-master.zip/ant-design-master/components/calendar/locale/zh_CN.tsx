import zh_CN from '../../date-picker/locale/zh_CN';
export default zh_CN;
