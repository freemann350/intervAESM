import pt_BR from '../../date-picker/locale/pt_BR';
export default pt_BR;
