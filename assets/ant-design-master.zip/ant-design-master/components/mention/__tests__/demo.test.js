import demoTest from '../../../tests/shared/demoTest';

demoTest('mention', { skip: true });
