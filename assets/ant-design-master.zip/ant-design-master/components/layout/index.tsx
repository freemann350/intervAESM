import Layout from './layout';
import Sider from './Sider';

Layout.Sider = Sider;
export default Layout;
