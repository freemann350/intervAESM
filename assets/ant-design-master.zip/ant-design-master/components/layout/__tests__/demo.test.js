import demoTest from '../../../tests/shared/demoTest';

demoTest('layout');
