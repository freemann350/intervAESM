import Input from './Input';
import Group from './Group';
import Search from './Search';

Input.Group = Group;
Input.Search = Search;
export default Input;
